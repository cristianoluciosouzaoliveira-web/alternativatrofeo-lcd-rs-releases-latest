//! Extra system information for the `pro` dashboard (see `pro.rs`):
//! usage of the system drive and the temperature of the disk it lives on.
//!
//! Read on a small background thread every few seconds (the disk does not need
//! more), so the render loop only copies the last value.
//!
//! - Usage: `sysinfo::Disks` (any platform).
//! - Temperature (Windows): `IOCTL_STORAGE_QUERY_PROPERTY` /
//!   `StorageDeviceTemperatureProperty` on the physical drive that holds the
//!   system drive — the same value NVMe/SATA drives report to Task Manager /
//!   CrystalDiskInfo. `None` if the drive or its driver does not report it.

use std::sync::{Arc, Mutex};
use std::time::Duration;

/// One physical drive (model name + temperature), for the STORAGE tile.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct DriveTemp {
    pub name: String,
    pub temp_c: Option<i32>,
}

/// All physical drives with their temperatures (Windows); empty elsewhere.
#[cfg(windows)]
pub fn read_drives() -> Vec<DriveTemp> {
    disk_temp::list()
        .into_iter()
        .map(|(n, model, t)| DriveTemp {
            name: if model.is_empty() { format!("Disk {n}") } else { model },
            temp_c: t.map(|(c, _)| c),
        })
        .collect()
}

#[cfg(not(windows))]
pub fn read_drives() -> Vec<DriveTemp> {
    Vec::new()
}

#[derive(Clone, Debug, Default, PartialEq)]
pub struct DiskInfo {
    /// "C:" (or the mount point on Linux).
    pub label: String,
    pub used_gb: f64,
    pub total_gb: f64,
    pub temp_c: Option<i32>,
}

impl DiskInfo {
    pub fn used_frac(&self) -> f32 {
        if self.total_gb > 0.0 {
            (self.used_gb / self.total_gb).clamp(0.0, 1.0) as f32
        } else {
            0.0
        }
    }
}

/// What the background reader last found.
#[derive(Clone, Debug, Default)]
pub struct Extra {
    pub disk: Option<DiskInfo>,
    /// Every physical drive with its temperature (the STORAGE tile lists them).
    pub drives: Vec<DriveTemp>,
    /// CPU fan speed, when HWiNFO is running with "Shared Memory Support" on.
    pub cpu_fan_rpm: Option<u32>,
    /// Water cooler pump RPM (CPU_OPT header), native reader only.
    pub pump_rpm: Option<u32>,
    /// GPU hotspot/junction temperature (°C). First choice: read natively from the GPU
    /// registers through the PawnIO `Nvidia` module (RTX 50, see `gpu_hotspot.rs`); then
    /// HWiNFO's shared memory (Settings -> "Shared Memory Support"; RTX 50 needs 8.51+).
    /// NVML has no such sensor. `None` if neither source works.
    pub gpu_hotspot_c: Option<i32>,
    /// Hottest GPU memory chip (°C) read natively; used when NVML has no memory temperature.
    pub gpu_mem_c: Option<i32>,
}

pub type SharedExtra = Arc<Mutex<Extra>>;

/// Starts the background reader: the CPU fan every 2 s, the disk every 10 s.
pub fn spawn_watcher() -> SharedExtra {
    let shared: SharedExtra = Arc::new(Mutex::new(Extra::default()));
    let out = shared.clone();
    let _ = std::thread::Builder::new().name("sys-extra".into()).spawn(move || {
        let mut n = 0u32;
        // Opening PawnIO + scanning the PCI bus for the GPU takes a moment, so it is done
        // here (never in the render loop) and retried about once a minute if it fails
        // (driver installed later, Nvidia.bin copied later, GPU waking up...).
        let mut native_hotspot: Option<crate::gpu_hotspot::NvHotspot> = None;
        let mut native_fans: Option<crate::superio_fan::ItFans> = None;
        let mut last_fan_err = String::new();
        let mut last_err = String::new();
        let mut tick = 0u32;
        loop {
            if native_hotspot.is_none() && tick % 30 == 0 {
                match crate::gpu_hotspot::NvHotspot::new() {
                    Ok(h) => {
                        eprintln!("GPU hotspot: native PawnIO reader active");
                        native_hotspot = Some(h);
                    }
                    Err(e) => {
                        if e != last_err {
                            eprintln!("GPU hotspot: native reader not active ({e}); using HWiNFO if available");
                            last_err = e;
                        }
                    }
                }
            }
            if native_fans.is_none() && tick % 30 == 0 {
                match crate::superio_fan::ItFans::new() {
                    Ok(f) => {
                        eprintln!("CPU fan: native PawnIO LpcIO reader active");
                        native_fans = Some(f);
                    }
                    Err(e) => {
                        if e != last_fan_err {
                            eprintln!("CPU fan: native reader not active ({e}); using HWiNFO if available");
                            last_fan_err = e;
                        }
                    }
                }
            }
            tick = tick.wrapping_add(1);
            // native Super I/O first (no HWiNFO needed), HWiNFO as fallback
            let (fan_native, pump) = native_fans.as_ref().and_then(|f| f.fan_rpms()).unwrap_or((None, None));
            let fan = fan_native.or_else(hwinfo_cpu_fan);
            let hotspot = native_hotspot
                .as_ref()
                .and_then(|h| h.hotspot_c())
                .or_else(hwinfo_gpu_hotspot);
            let mem = native_hotspot.as_ref().and_then(|h| h.mem_temp_c());
            let disk = (n % 5 == 0).then(read_disk);
            let drives = (n % 5 == 0).then(read_drives);
            if let Ok(mut g) = out.lock() {
                g.cpu_fan_rpm = fan;
                g.pump_rpm = pump;
                g.gpu_hotspot_c = hotspot;
                g.gpu_mem_c = mem;
                if let Some(d) = disk {
                    g.disk = d;
                }
                if let Some(d) = drives {
                    g.drives = d;
                }
            }
            n = n.wrapping_add(1);
            std::thread::sleep(Duration::from_secs(2));
        }
    });
    shared
}

/// CPU fan RPM from HWiNFO's shared memory (`Global\HWiNFO_SENS_SM2`), if HWiNFO
/// is running with Settings -> "Shared Memory Support" enabled. `None` otherwise.
#[cfg(windows)]
pub fn hwinfo_cpu_fan() -> Option<u32> {
    hwinfo_readings(HWINFO_FAN).and_then(|fans| pick_cpu_fan(&fans))
}

#[cfg(not(windows))]
pub fn hwinfo_cpu_fan() -> Option<u32> {
    None
}

/// GPU hotspot (°C) from HWiNFO's shared memory, if HWiNFO runs with "Shared Memory
/// Support" and the card exposes one (RTX 50 needs HWiNFO 8.51+). `None` otherwise.
#[cfg(windows)]
pub fn hwinfo_gpu_hotspot() -> Option<i32> {
    hwinfo_readings(HWINFO_TEMP).and_then(|t| pick_gpu_hotspot(&t))
}

#[cfg(not(windows))]
pub fn hwinfo_gpu_hotspot() -> Option<i32> {
    None
}

/// Picks the GPU hotspot among (label, °C) temperature readings: a label with "hot spot"
/// / "hotspot" / "junction" and "gpu", excluding memory junction ("GPU Memory Junction
/// Temperature" is the GDDR6X sensor, not the die). Values outside 1..=150 are dropped
/// (older builds showed 255 °C on RTX 50 = invalid marker).
pub fn pick_gpu_hotspot(temps: &[(String, f64)]) -> Option<i32> {
    temps
        .iter()
        .filter(|(n, v)| {
            let n = n.to_ascii_lowercase();
            n.contains("gpu")
                && (n.contains("hot spot") || n.contains("hotspot") || n.contains("junction"))
                && !n.contains("mem")
                && (1.0..=150.0).contains(v)
        })
        .map(|(_, v)| v.round() as i32)
        .next()
}

/// HWiNFO `SENSOR_READING_TYPE` values we care about.
#[cfg(windows)]
const HWINFO_TEMP: u32 = 1;
#[cfg(windows)]
const HWINFO_FAN: u32 = 3;

/// Picks the CPU fan among (label, rpm) readings: "CPU" / "CPU Fan" first, then any
/// label containing "CPU" (not "OPT"/"PUMP"), then "CPU OPT".
pub fn pick_cpu_fan(fans: &[(String, f64)]) -> Option<u32> {
    let l = |s: &str| s.to_ascii_lowercase();
    let exact = fans.iter().find(|(n, _)| matches!(l(n).trim(), "cpu" | "cpu fan" | "cpu_fan" | "cpu fan1"));
    let any = || fans.iter().find(|(n, _)| { let n = l(n); n.contains("cpu") && !n.contains("opt") && !n.contains("pump") });
    let opt = || fans.iter().find(|(n, _)| l(n).contains("cpu"));
    exact.or_else(any).or_else(opt).map(|(_, v)| v.max(0.0).round() as u32)
}

/// All (label, value) readings of one HWiNFO reading type (1 = temperature, 3 = fan).
#[cfg(windows)]
fn hwinfo_readings(kind: u32) -> Option<Vec<(String, f64)>> {
    use std::ffi::c_void;
    #[link(name = "kernel32")]
    extern "system" {
        fn OpenFileMappingW(access: u32, inherit: i32, name: *const u16) -> isize;
        fn MapViewOfFile(h: isize, access: u32, hi: u32, lo: u32, bytes: usize) -> *const c_void;
        fn UnmapViewOfFile(base: *const c_void) -> i32;
        fn CloseHandle(h: isize) -> i32;
    }
    const FILE_MAP_READ: u32 = 4;
    let name: Vec<u16> = "Global\\HWiNFO_SENS_SM2".encode_utf16().chain(std::iter::once(0)).collect();
    let h = unsafe { OpenFileMappingW(FILE_MAP_READ, 0, name.as_ptr()) };
    if h == 0 {
        return None;
    }
    let base = unsafe { MapViewOfFile(h, FILE_MAP_READ, 0, 0, 0) } as *const u8;
    if base.is_null() {
        unsafe { CloseHandle(h) };
        return None;
    }
    let rd32 = |off: usize| -> u32 { unsafe { std::ptr::read_unaligned(base.add(off) as *const u32) } };
    let mut out = Vec::new();
    // header (packed): signature 'HWiS' at 0, reading section offset/size/count at 32/36/40
    let sig = unsafe { std::slice::from_raw_parts(base, 4) };
    if sig == b"HWiS" {
        let (off, size, count) = (rd32(32) as usize, rd32(36) as usize, rd32(40) as usize);
        if size >= 292 && count < 10_000 {
            for i in 0..count {
                let e = off + i * size;
                if rd32(e) != kind {
                    continue;
                }
                let label = |o: usize| -> String {
                    let bytes = unsafe { std::slice::from_raw_parts(base.add(e + o), 128) };
                    let end = bytes.iter().position(|b| *b == 0).unwrap_or(128);
                    String::from_utf8_lossy(&bytes[..end]).trim().to_string()
                };
                let user = label(140);
                let name = if user.is_empty() { label(12) } else { user };
                let value = unsafe { std::ptr::read_unaligned(base.add(e + 284) as *const f64) };
                out.push((name, value));
            }
        }
    }
    unsafe {
        UnmapViewOfFile(base as *const c_void);
        CloseHandle(h);
    }
    Some(out)
}

/// The system drive: `%SystemDrive%` on Windows, `/` elsewhere.
fn system_mount() -> String {
    #[cfg(windows)]
    {
        let d = std::env::var("SystemDrive").unwrap_or_else(|_| "C:".to_string());
        format!("{}\\", d.trim_end_matches('\\'))
    }
    #[cfg(not(windows))]
    {
        "/".to_string()
    }
}

pub fn read_disk() -> Option<DiskInfo> {
    let mount = system_mount();
    let disks = sysinfo::Disks::new_with_refreshed_list();
    let disk = disks
        .list()
        .iter()
        .find(|d| d.mount_point().to_string_lossy().eq_ignore_ascii_case(&mount))
        .or_else(|| disks.list().iter().max_by_key(|d| d.total_space()))?;
    let total = disk.total_space() as f64;
    let used = total - disk.available_space() as f64;
    let gb = 1024.0 * 1024.0 * 1024.0;
    let label = mount.trim_end_matches(['\\', '/']).to_string();
    Some(DiskInfo {
        label: if label.is_empty() { "/".into() } else { label },
        used_gb: used / gb,
        total_gb: total / gb,
        temp_c: disk_temperature(&mount),
    })
}

/// Drive temperatures on Windows. Three methods are tried per physical drive, in this order:
///  1. `StorageDeviceTemperatureProperty` (works on most NVMe/SATA with a Windows driver that fills it),
///  2. NVMe SMART/Health log page (temperature in Kelvin, bytes 1-2),
///  3. ATA SMART attribute 194/190 (SATA SSD/HDD; needs administrator).
/// Written from the Windows storage structures, validate it with `--diag` (lists every drive).
#[cfg(windows)]
mod disk_temp {
    use std::ffi::c_void;

    #[link(name = "kernel32")]
    extern "system" {
        fn CreateFileW(name: *const u16, access: u32, share: u32, sa: *mut c_void, disposition: u32, flags: u32, template: *mut c_void) -> isize;
        fn DeviceIoControl(h: isize, code: u32, inb: *const c_void, insz: u32, outb: *mut c_void, outsz: u32, ret: *mut u32, ov: *mut c_void) -> i32;
        fn CloseHandle(h: isize) -> i32;
    }
    const FILE_SHARE_RW: u32 = 3;
    const OPEN_EXISTING: u32 = 3;
    const GENERIC_RW: u32 = 0xC000_0000;
    const IOCTL_STORAGE_GET_DEVICE_NUMBER: u32 = 0x002D_1080;
    const IOCTL_STORAGE_QUERY_PROPERTY: u32 = 0x002D_1400;
    const SMART_RCV_DRIVE_DATA: u32 = 0x0007_C088;

    fn open(path: &str, access: u32) -> Option<isize> {
        let wide: Vec<u16> = path.encode_utf16().chain(std::iter::once(0)).collect();
        let h = unsafe { CreateFileW(wide.as_ptr(), access, FILE_SHARE_RW, std::ptr::null_mut(), OPEN_EXISTING, 0, std::ptr::null_mut()) };
        (h != -1 && h != 0).then_some(h)
    }

    /// DeviceIoControl with byte buffers; returns the number of bytes written to `out`.
    fn ioctl(h: isize, code: u32, input: &[u8], out: &mut [u8]) -> Option<usize> {
        let mut ret = 0u32;
        let ok = unsafe {
            DeviceIoControl(h, code, input.as_ptr() as *const c_void, input.len() as u32, out.as_mut_ptr() as *mut c_void, out.len() as u32, &mut ret, std::ptr::null_mut())
        };
        (ok != 0).then_some(ret as usize)
    }

    fn put32(b: &mut [u8], off: usize, v: u32) {
        b[off..off + 4].copy_from_slice(&v.to_le_bytes());
    }

    fn plausible(t: i32) -> Option<i32> {
        (1..=125).contains(&t).then_some(t)
    }

    /// Physical drive number holding a volume such as `C:\`.
    pub fn drive_of_mount(mount: &str) -> Option<u32> {
        let h = open(&format!("\\\\.\\{}", mount.trim_end_matches('\\')), 0)?;
        let mut num = [0u8; 12]; // STORAGE_DEVICE_NUMBER: type, number, partition
        let r = ioctl(h, IOCTL_STORAGE_GET_DEVICE_NUMBER, &[], &mut num);
        unsafe { CloseHandle(h) };
        r?;
        Some(u32::from_le_bytes([num[4], num[5], num[6], num[7]]))
    }

    /// Method 1: StorageDeviceTemperatureProperty (52).
    fn by_property(n: u32) -> Option<i32> {
        let h = open(&format!("\\\\.\\PhysicalDrive{n}"), 0)?;
        let mut q = [0u8; 12];
        put32(&mut q, 0, 52);
        let mut buf = [0u8; 512];
        let r = ioctl(h, IOCTL_STORAGE_QUERY_PROPERTY, &q, &mut buf);
        unsafe { CloseHandle(h) };
        let ret = r?;
        if ret < 28 {
            return None;
        }
        // STORAGE_TEMPERATURE_DATA_DESCRIPTOR: InfoCount (u16) at 12, STORAGE_TEMPERATURE_INFO[] (16 bytes) from 24, Temperature (i16) at +2
        let count = u16::from_le_bytes([buf[12], buf[13]]) as usize;
        (0..count.min(8))
            .filter_map(|i| {
                let o = 24 + i * 16 + 2;
                (o + 2 <= ret).then(|| i16::from_le_bytes([buf[o], buf[o + 1]]) as i32)
            })
            .find_map(plausible)
    }

    /// Method 2: NVMe SMART / Health log page (id 2): composite temperature in Kelvin at bytes 1-2.
    fn by_nvme_smart(n: u32) -> Option<i32> {
        for access in [0u32, GENERIC_RW] {
            let Some(h) = open(&format!("\\\\.\\PhysicalDrive{n}"), access) else { continue };
            for sub in [0u32, 0xFFFF_FFFF] {
                // STORAGE_PROPERTY_QUERY (PropertyId, QueryType) + STORAGE_PROTOCOL_SPECIFIC_DATA (40 bytes) at 8, data at 48
                let mut buf = vec![0u8; 48 + 512];
                put32(&mut buf, 0, 50); // StorageDeviceProtocolSpecificProperty
                put32(&mut buf, 4, 0); // PropertyStandardQuery
                put32(&mut buf, 8, 3); // ProtocolTypeNvme
                put32(&mut buf, 12, 2); // NVMeDataTypeLogPage
                put32(&mut buf, 16, 2); // NVME_LOG_PAGE_HEALTH_INFO
                put32(&mut buf, 20, sub); // namespace
                put32(&mut buf, 24, 40); // ProtocolDataOffset (sizeof STORAGE_PROTOCOL_SPECIFIC_DATA)
                put32(&mut buf, 28, 512); // ProtocolDataLength
                let input = buf.clone();
                if let Some(ret) = ioctl(h, IOCTL_STORAGE_QUERY_PROPERTY, &input, &mut buf) {
                    if ret >= 51 {
                        let kelvin = u16::from_le_bytes([buf[49], buf[50]]) as i32;
                        if kelvin > 0 {
                            if let Some(t) = plausible(kelvin - 273) {
                                unsafe { CloseHandle(h) };
                                return Some(t);
                            }
                        }
                    }
                }
            }
            unsafe { CloseHandle(h) };
        }
        None
    }

    /// Method 3: ATA SMART READ DATA, attribute 194 (temperature) or 190 (airflow temperature); raw low byte is °C.
    fn by_ata_smart(n: u32) -> Option<i32> {
        let h = open(&format!("\\\\.\\PhysicalDrive{n}"), GENERIC_RW)?;
        let mut input = [0u8; 32]; // SENDCMDINPARAMS without the trailing buffer byte
        put32(&mut input, 0, 512); // cBufferSize
        input[4] = 0xD0; // bFeaturesReg: SMART_READ_DATA
        input[5] = 1; // sector count
        input[6] = 1; // sector number
        input[7] = 0x4F; // cylinder low
        input[8] = 0xC2; // cylinder high
        input[9] = 0xA0 | (((n & 1) as u8) << 4); // drive/head
        input[10] = 0xB0; // SMART_CMD
        input[12] = n as u8; // bDriveNumber
        let mut out = vec![0u8; 16 + 512]; // SENDCMDOUTPARAMS: cBufferSize + DRIVERSTATUS (12) + 512 data
        let r = ioctl(h, SMART_RCV_DRIVE_DATA, &input, &mut out);
        unsafe { CloseHandle(h) };
        let ret = r?;
        if ret < 16 + 512 {
            return None;
        }
        let data = &out[16..16 + 512];
        let mut found = None;
        for i in 0..30 {
            let o = 2 + i * 12;
            let id = data[o];
            if id == 194 || id == 190 {
                let t = plausible(data[o + 5] as i32);
                if id == 194 && t.is_some() {
                    return t;
                }
                found = found.or(t);
            }
        }
        found
    }

    /// Temperature of one physical drive and which method produced it.
    pub fn drive_temp(n: u32) -> Option<(i32, &'static str)> {
        by_property(n)
            .map(|t| (t, "storage property"))
            .or_else(|| by_nvme_smart(n).map(|t| (t, "NVMe SMART")))
            .or_else(|| by_ata_smart(n).map(|t| (t, "ATA SMART")))
    }

    /// Product name (STORAGE_DEVICE_DESCRIPTOR).
    fn model(n: u32) -> String {
        let Some(h) = open(&format!("\\\\.\\PhysicalDrive{n}"), 0) else { return String::new() };
        let q = [0u8; 12]; // PropertyId = StorageDeviceProperty (0), PropertyStandardQuery (0)
        let mut buf = [0u8; 1024];
        let r = ioctl(h, IOCTL_STORAGE_QUERY_PROPERTY, &q, &mut buf);
        unsafe { CloseHandle(h) };
        let Some(ret) = r else { return String::new() };
        if ret < 20 {
            return String::new();
        }
        let off = u32::from_le_bytes([buf[16], buf[17], buf[18], buf[19]]) as usize;
        if off == 0 || off >= ret {
            return String::new();
        }
        let end = buf[off..ret].iter().position(|b| *b == 0).map_or(ret, |p| off + p);
        String::from_utf8_lossy(&buf[off..end]).trim().to_string()
    }

    /// Every physical drive found (0..16): number, model, temperature + method.
    pub fn list() -> Vec<(u32, String, Option<(i32, &'static str)>)> {
        (0..16u32)
            .filter(|n| open(&format!("\\\\.\\PhysicalDrive{n}"), 0).map(|h| unsafe { CloseHandle(h) }).is_some())
            .map(|n| (n, model(n), drive_temp(n)))
            .collect()
    }
}

#[cfg(windows)]
fn disk_temperature(mount: &str) -> Option<i32> {
    let n = disk_temp::drive_of_mount(mount)?;
    disk_temp::drive_temp(n).map(|(t, _)| t)
}

/// Text report for `--diag`: every physical drive with the temperature method that worked.
#[cfg(windows)]
pub fn disks_diag() -> String {
    let mut s = String::from("Physical drives (temperature method that worked):\n");
    let list = disk_temp::list();
    if list.is_empty() {
        s.push_str("  none found (run as administrator)\n");
    }
    for (n, model, t) in list {
        match t {
            Some((c, how)) => s.push_str(&format!("  PhysicalDrive{n}  {model}: {c} C  [{how}]\n")),
            None => s.push_str(&format!("  PhysicalDrive{n}  {model}: no temperature (property, NVMe SMART and ATA SMART all failed)\n")),
        }
    }
    s
}

#[cfg(not(windows))]
pub fn disks_diag() -> String {
    String::new()
}

#[cfg(not(windows))]
fn disk_temperature(_mount: &str) -> Option<i32> {
    None
}

/// "AMD Ryzen 7 5800X 8-Core Processor" -> "AMD Ryzen 7 5800X".
pub fn clean_cpu_name(raw: &str) -> String {
    let mut s = raw.replace("(R)", "").replace("(TM)", "").replace("(tm)", "");
    for cut in [" with Radeon", " w/ Radeon", " CPU @", " @ "] {
        if let Some(i) = s.find(cut) {
            s.truncate(i);
        }
    }
    let words: Vec<&str> = s.split_whitespace().collect();
    let mut out: Vec<&str> = Vec::new();
    for (i, w) in words.iter().enumerate() {
        let lw = w.to_ascii_lowercase();
        let core_word = lw.ends_with("-core") || lw == "processor" || (lw.ends_with("-core") && i + 1 < words.len());
        if core_word {
            break;
        }
        out.push(w);
    }
    let s = out.join(" ");
    if s.is_empty() { raw.trim().to_string() } else { s }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn cpu_fan_is_picked() {
        let f = |v: &[(&str, f64)]| pick_cpu_fan(&v.iter().map(|(a, b)| (a.to_string(), *b)).collect::<Vec<_>>());
        assert_eq!(f(&[("System 1", 900.0), ("CPU", 1210.4), ("CPU OPT", 0.0)]), Some(1210));
        assert_eq!(f(&[("CPU OPT", 800.0)]), Some(800));
        assert_eq!(f(&[("Chassis", 800.0)]), None);
    }

    #[test]
    fn gpu_hotspot_is_picked() {
        let f = |v: &[(&str, f64)]| pick_gpu_hotspot(&v.iter().map(|(a, b)| (a.to_string(), *b)).collect::<Vec<_>>());
        // RTX 20/30/40 and AMD: the die hotspot, never the GDDR6X memory junction
        assert_eq!(f(&[("GPU Temperature", 66.0), ("GPU Memory Junction Temperature", 90.0), ("GPU Hot Spot Temperature", 78.4)]), Some(78));
        // RTX 50: early HWiNFO builds reported 255 (invalid marker) -> ignored
        assert_eq!(f(&[("GPU Temperature", 66.0), ("GPU Hot Spot Temperature", 255.0)]), None);
        // no hotspot sensor at all (RTX 50 today), or a non-GPU "hot spot"
        assert_eq!(f(&[("GPU Temperature", 66.0), ("GPU Memory Temperature", 70.0)]), None);
        assert_eq!(f(&[("CPU Hot Spot", 70.0)]), None);
    }

    #[test]
    fn cpu_names_are_shortened() {
        assert_eq!(clean_cpu_name("AMD Ryzen 7 5800X 8-Core Processor"), "AMD Ryzen 7 5800X");
        assert_eq!(clean_cpu_name("Intel(R) Core(TM) i7-9700K CPU @ 3.60GHz"), "Intel Core i7-9700K");
        assert_eq!(clean_cpu_name("AMD Ryzen 5 5600G with Radeon Graphics"), "AMD Ryzen 5 5600G");
    }
}
