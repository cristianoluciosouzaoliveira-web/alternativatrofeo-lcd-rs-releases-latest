//! **Native fan RPM** (CPU_FAN = the water cooler's radiator fans) read from the motherboard's
//! **ITE IT8689E** Super I/O chip, with no HWiNFO / AIDA64 running.
//!
//! Access goes through the official, signed **`LpcIO` module of PawnIO**
//! (<https://github.com/namazso/PawnIO.Modules>, `LpcIO.p`). That module only exposes the Super I/O
//! configuration ports and the I/O ranges (BARs) the chip itself announces, so it cannot be used to
//! poke arbitrary ports. The register layout is the one of the Linux `it87` driver:
//!
//! * enter the ITE configuration mode (0x87, 0x01, 0x55, 0x55 on port 0x2E; ...0xAA on 0x4E),
//! * chip id (reg 0x20/0x21) must be 0x8689, select logical device 4 (environment controller),
//!   its I/O base is in reg 0x60/0x61 (AIDA64 reports it as "ISA A40h" on this board),
//! * fan tachometers: index port = base + 5, data port = base + 6,
//!   low byte regs `0D 0E 0F 80 82 4C`, high byte regs `18 19 1A 81 83 4D`,
//!   the IT8689E tachometers are always 16-bit: `RPM = 1_350_000 / (value * 2)` (measured on a real board:
//!   reg 0x0C does not report it, and reading them as 8-bit gives absurd 10000+ RPM).
//!
//! Monitoring tools share the bus through the global mutex `Access_ISABUS.HTP.Method`
//! (motherboard vendors' own software uses it too), so it is taken around every access.
//!
//! Which tachometer is the CPU_FAN header depends on the board; `--diag` prints all six so they can be
//! matched against another monitor. `TROFEO_CPU_FAN_TACH=<1-6>` selects the radiator-fan tach (default 1, which is
//! CPU_FAN on the author's Gigabyte board) and `TROFEO_PUMP_TACH=<1-6|off>` the pump tach (default 5 = CPU_OPT).
//!
//! Requirements: the PawnIO driver and `LpcIO.bin` (signed, from the PawnIO.Modules releases) next to
//! the program, or its path in `TROFEO_LPCIO_MODULE`. Only the IT8689E is supported for now. Other
//! Super I/O families use other protocols, and probing an unknown chip is deliberately not attempted.
//!
//! NOTE: written from the module source and the it87 register map, validate with `--diag` against AIDA64.

#[cfg(windows)]
mod imp {
    use crate::pawnio::PawnIo;
    use std::ffi::c_void;
    use std::path::PathBuf;

    const MODULE_FILE: &str = "LpcIO.bin";
    /// Chip ids this reader knows the register layout of.
    const SUPPORTED_CHIPS: &[u64] = &[0x8689]; // IT8689E
    const FAN_LOW: [u64; 6] = [0x0D, 0x0E, 0x0F, 0x80, 0x82, 0x4C];
    const FAN_HIGH: [u64; 6] = [0x18, 0x19, 0x1A, 0x81, 0x83, 0x4D];
    const LDN_ENVIRONMENT: u64 = 0x04;
    const EC_INDEX_OFFSET: u64 = 0x05;
    const EC_DATA_OFFSET: u64 = 0x06;

    #[link(name = "kernel32")]
    extern "system" {
        fn CreateMutexW(attrs: *mut c_void, initial_owner: i32, name: *const u16) -> isize;
        fn WaitForSingleObject(h: isize, ms: u32) -> u32;
        fn ReleaseMutex(h: isize) -> i32;
        fn CloseHandle(h: isize) -> i32;
    }

    /// The global mutex other monitoring tools / vendor software take around Super I/O access.
    struct IsaBusLock(isize);

    impl IsaBusLock {
        fn acquire() -> Option<Self> {
            let name: Vec<u16> = "Global\\Access_ISABUS.HTP.Method".encode_utf16().chain(std::iter::once(0)).collect();
            let h = unsafe { CreateMutexW(std::ptr::null_mut(), 0, name.as_ptr()) };
            if h == 0 {
                return None;
            }
            let r = unsafe { WaitForSingleObject(h, 300) };
            if r == 0 || r == 0x80 {
                // WAIT_OBJECT_0 or WAIT_ABANDONED (a previous owner died): we own it now
                Some(IsaBusLock(h))
            } else {
                unsafe { CloseHandle(h) };
                None
            }
        }
    }

    impl Drop for IsaBusLock {
        fn drop(&mut self) {
            unsafe {
                ReleaseMutex(self.0);
                CloseHandle(self.0);
            }
        }
    }

    fn candidates() -> Vec<PathBuf> {
        let mut v = Vec::new();
        if let Ok(p) = std::env::var("TROFEO_LPCIO_MODULE") {
            v.push(PathBuf::from(p));
        }
        if let Ok(exe) = std::env::current_exe() {
            if let Some(dir) = exe.parent() {
                v.push(dir.join(MODULE_FILE));
                v.push(dir.join("resources").join(MODULE_FILE));
            }
        }
        v.push(PathBuf::from(MODULE_FILE));
        v
    }

    /// One tachometer reading, with the raw bytes for diagnostics.
    #[derive(Clone, Copy, Debug)]
    pub struct Tach {
        pub low: u64,
        pub high: u64,
        pub rpm: u32,
    }

    pub struct ItFans {
        pawnio: PawnIo,
        chip: u64,
        slot: u64,
        base: u64,
    }

    impl ItFans {
        /// Opens PawnIO + the LpcIO module and finds the IT8689E environment controller.
        /// Does a few port accesses, so call it from a background thread.
        pub fn new() -> Result<Self, String> {
            let blob = candidates()
                .into_iter()
                .find_map(|p| std::fs::read(p).ok())
                .filter(|b| !b.is_empty())
                .ok_or_else(|| format!("{MODULE_FILE} not found (put it next to the program or set TROFEO_LPCIO_MODULE)"))?;
            let pawnio = PawnIo::open_with_module(&blob).ok_or(
                "PawnIO refused the LpcIO module: run as administrator, check that the PawnIO driver is installed, \
                 and that LpcIO.bin is a signed build from the PawnIO.Modules releases",
            )?;
            let _bus = IsaBusLock::acquire().ok_or("the Super I/O bus is busy (another monitoring tool holds the ISA bus mutex)")?;

            for slot in [0u64, 1] {
                if pawnio.execute("ioctl_select_slot", &[slot], 0).is_none() {
                    continue;
                }
                let reg_port = if slot == 0 { 0x2E } else { 0x4E };
                // ITE "enter configuration mode" key
                for v in [0x87u64, 0x01, 0x55, if slot == 0 { 0x55 } else { 0xAA }] {
                    pawnio.execute("ioctl_pio_outb", &[reg_port, v], 0);
                }
                let chip = pawnio.execute("ioctl_superio_inw", &[0x20], 1).and_then(|v| v.first().copied()).unwrap_or(0);
                if !SUPPORTED_CHIPS.contains(&chip) {
                    if chip != 0 && chip != 0xFFFF {
                        // some other chip opened its configuration mode: leave it as we found it
                        pawnio.execute("ioctl_superio_outb", &[0x02, 0x02], 0);
                    }
                    continue;
                }
                // environment controller: logical device 4, I/O base in 0x60/0x61 (read twice: must be stable)
                pawnio.execute("ioctl_superio_outb", &[0x07, LDN_ENVIRONMENT], 0);
                let base = pawnio.execute("ioctl_superio_inw", &[0x60], 1).and_then(|v| v.first().copied()).unwrap_or(0);
                let again = pawnio.execute("ioctl_superio_inw", &[0x60], 1).and_then(|v| v.first().copied()).unwrap_or(1);
                // let the module learn the chip's I/O ranges so it allows reading base+5/+6
                pawnio.execute("ioctl_find_bars", &[], 0);
                // ITE "exit configuration mode"
                pawnio.execute("ioctl_superio_outb", &[0x02, 0x02], 0);
                if base != again || base < 0x100 || base & 0xF007 != 0 {
                    return Err(format!("IT{chip:04X} found but its environment controller base address looks invalid (0x{base:X})"));
                }
                return Ok(ItFans { pawnio, chip, slot, base });
            }
            Err("no supported Super I/O chip answered (only the ITE IT8689E is supported; other boards use other chips)".into())
        }

        fn ec_read(&self, reg: u64) -> Option<u64> {
            self.pawnio.execute("ioctl_pio_outb", &[self.base + EC_INDEX_OFFSET, reg], 0)?;
            self.pawnio.execute("ioctl_pio_inb", &[self.base + EC_DATA_OFFSET], 1).and_then(|v| v.first().map(|b| b & 0xFF))
        }

        /// All six tachometers.
        pub fn tachs(&self) -> Option<[Tach; 6]> {
            let _bus = IsaBusLock::acquire()?;
            let mut out = [Tach { low: 0, high: 0, rpm: 0 }; 6];
            for i in 0..6 {
                let low = self.ec_read(FAN_LOW[i])?;
                let high = self.ec_read(FAN_HIGH[i])?;
                let v = low | (high << 8);
                let rpm = if v == 0 || v == 0xFFFF { 0 } else { 1_350_000 / (v * 2) };
                out[i] = Tach { low, high, rpm: rpm.min(30_000) as u32 };
            }
            Some(out)
        }

        /// 0-based tachometer index from an environment variable holding 1-6 (`0` / `off` disables it);
        /// `default` (1-based) when the variable is unset or invalid.
        fn tach_choice(var: &str, default: usize) -> Option<usize> {
            match std::env::var(var) {
                Ok(v) => {
                    let v = v.trim().to_lowercase();
                    if v == "0" || v == "off" {
                        None
                    } else {
                        Some(v.parse::<usize>().ok().filter(|n| (1..=6).contains(n)).unwrap_or(default) - 1)
                    }
                }
                Err(_) => Some(default - 1),
            }
        }

        /// `(radiator fans RPM, pump RPM)` from one read. Radiator fans = CPU_FAN = tach 1
        /// (`TROFEO_CPU_FAN_TACH`), pump = CPU_OPT = tach 5 (`TROFEO_PUMP_TACH`, `off` to hide it); both
        /// matched against AIDA64 on a Gigabyte A620/B650 board. A tach that reads 0 gives `None`.
        pub fn fan_rpms(&self) -> Option<(Option<u32>, Option<u32>)> {
            let t = self.tachs()?;
            let pick = |var: &str, def: usize| Self::tach_choice(var, def).map(|i| t[i].rpm).filter(|r| *r > 0);
            Some((pick("TROFEO_CPU_FAN_TACH", 1), pick("TROFEO_PUMP_TACH", 5)))
        }

        /// Text report for `--diag`.
        pub fn diag(&self) -> String {
            let mut s = format!(
                "Native fans (PawnIO LpcIO module): ITE IT{:04X} at EC base 0x{:X} (slot {})\n",
                self.chip, self.base, self.slot
            );
            match self.tachs() {
                Some(t) => {
                    for (i, x) in t.iter().enumerate() {
                        s.push_str(&format!(
                            "  tach {}: low=0x{:02X} high=0x{:02X} (16-bit) -> {} RPM\n",
                            i + 1,
                            x.low,
                            x.high,
                            x.rpm
                        ));
                    }
                    s.push_str("  (the CPU_FAN / water cooler fans are the tach whose RPM matches your other monitor; set TROFEO_CPU_FAN_TACH to its number)\n");
                }
                None => s.push_str("  tachometer read failed\n"),
            }
            s
        }
    }
}

#[cfg(not(windows))]
mod imp {
    pub struct ItFans;
    impl ItFans {
        pub fn new() -> Result<Self, String> {
            Err("Windows only".into())
        }
        pub fn fan_rpms(&self) -> Option<(Option<u32>, Option<u32>)> {
            None
        }
        pub fn diag(&self) -> String {
            String::new()
        }
    }
}

pub use imp::ItFans;
