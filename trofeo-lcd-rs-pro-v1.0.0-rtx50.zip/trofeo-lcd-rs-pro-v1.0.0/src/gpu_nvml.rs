//! NVIDIA GPU temperature and power. Two paths, in order:
//! 1. **NVML** (the GeForce driver's `nvml.dll`: System32, NVSMI or DriverStore),
//!    loaded dynamically;
//! 2. **nvidia-smi** (`nvidia-smi.exe`, always installed with the driver), launched
//!    in the background without a window every ~1.5 s.
//!
//! About the **hotspot** (junction) temperature: NVML has NO hotspot sensor, and on
//! GeForce RTX 50 (Blackwell) NVIDIA left it out of the public APIs. Since July 2026
//! HWiNFO (8.51+), HWMonitor (1.65+) and GPU-Z (2.71+) read it by other means, so the
//! hotspot is taken from HWiNFO's shared memory (see `sysextra.rs`). What NVML itself
//! gives is the GPU (average) temperature and the **memory** temperature.
//!
//! `NvSensor::new()` picks automatically and reports in `describe()` what it's
//! using (or why NVML didn't start). Without an NVIDIA driver it returns `None`.
//! Windows only.

#[cfg(windows)]
mod imp {
    use std::ffi::{c_void, CString};
    use std::os::windows::process::CommandExt;
    use std::path::PathBuf;
    use std::process::{Command, Stdio};
    use std::sync::{Arc, Mutex};
    use windows::core::PCSTR;
    use windows::Win32::System::LibraryLoader::{GetProcAddress, LoadLibraryA};

    type InitFn = unsafe extern "C" fn() -> i32;
    type HandleFn = unsafe extern "C" fn(u32, *mut *mut c_void) -> i32;
    type TempFn = unsafe extern "C" fn(*mut c_void, u32, *mut u32) -> i32;
    type PowerFn = unsafe extern "C" fn(*mut c_void, *mut u32) -> i32;
    type ClockFn = unsafe extern "C" fn(*mut c_void, u32, *mut u32) -> i32;
    /// (GPU temperature °C, power W, core clock MHz, memory temperature °C, (VRAM used MB, VRAM total MB),
    ///  (fan RPM, fan %): the fastest fan; RPM is `None` on drivers without `nvmlDeviceGetFanSpeedRPM`)
    pub type Reading = (Option<i32>, Option<i32>, Option<i32>, Option<i32>, Option<(i32, i32)>, (Option<i32>, Option<i32>));
    /// `nvmlFanSpeedInfo_t`: { version, fan, speed }.
    #[repr(C)]
    struct FanSpeedInfo {
        version: u32,
        fan: u32,
        speed: u32,
    }
    /// `nvmlFanSpeedInfo_v1`: NVML_STRUCT_VERSION = sizeof(struct) | (1 << 24).
    const FAN_SPEED_INFO_V1: u32 = 12 | (1 << 24);
    type NumFansFn = unsafe extern "C" fn(*mut c_void, *mut u32) -> i32;
    type FanPctFn = unsafe extern "C" fn(*mut c_void, u32, *mut u32) -> i32;
    type FanRpmFn = unsafe extern "C" fn(*mut c_void, *mut FanSpeedInfo) -> i32;
    /// `nvmlMemory_t` (v1): total / free / used in bytes.
    #[repr(C)]
    struct NvmlMemory {
        total: u64,
        free: u64,
        used: u64,
    }
    type MemInfoFn = unsafe extern "C" fn(*mut c_void, *mut NvmlMemory) -> i32;
    /// `nvmlFieldValue_t`: { fieldId, scopeId, timestamp, latencyUsec, valueType, nvmlReturn, value }.
    #[repr(C)]
    struct FieldValue {
        field_id: u32,
        scope_id: u32,
        timestamp: i64,
        latency_usec: i64,
        value_type: u32,
        nvml_return: u32,
        value: [u8; 8],
    }
    type FieldsFn = unsafe extern "C" fn(*mut c_void, i32, *mut FieldValue) -> i32;
    /// NVML_FI_DEV_MEMORY_TEMP: memory temperature (°C). Still exposed on RTX 50.
    const NVML_FI_DEV_MEMORY_TEMP: u32 = 82;
    /// `nvmlTemperature_t` (newer NVML / RTX 50): { version, sensorType, temperature }.
    #[repr(C)]
    struct TempV {
        version: u32,
        sensor_type: u32,
        temperature: i32,
    }
    type TempVFn = unsafe extern "C" fn(*mut c_void, *mut TempV) -> i32;
    /// NVML_STRUCT_VERSION(Temperature, 1) = sizeof | (1 << 24)
    const TEMP_V1: u32 = 12 | (1 << 24);

    struct Nvml {
        clock: Option<ClockFn>,
        dev: *mut c_void,
        temp: TempFn,
        temp_v: Option<TempVFn>,
        power: PowerFn,
        fields: Option<FieldsFn>,
        mem_info: Option<MemInfoFn>,
        num_fans: Option<NumFansFn>,
        fan_pct: Option<FanPctFn>,
        fan_rpm: Option<FanRpmFn>,
    }

    fn candidate_paths() -> Vec<String> {
        let mut v = vec![
            "nvml.dll".to_string(),
            "C:\\Windows\\System32\\nvml.dll".to_string(),
            "C:\\Program Files\\NVIDIA Corporation\\NVSMI\\nvml.dll".to_string(),
        ];
        // DriverStore: C:\Windows\System32\DriverStore\FileRepository\nv*\nvml.dll
        if let Ok(rd) = std::fs::read_dir("C:\\Windows\\System32\\DriverStore\\FileRepository") {
            for e in rd.flatten() {
                let name = e.file_name().to_string_lossy().to_ascii_lowercase();
                if name.starts_with("nv") {
                    let p = e.path().join("nvml.dll");
                    if p.is_file() {
                        v.push(p.to_string_lossy().into_owned());
                    }
                }
            }
        }
        v
    }

    impl Nvml {
        fn new() -> Result<Self, String> {
            unsafe {
                let mut module = None;
                for path in candidate_paths() {
                    let c = CString::new(path).map_err(|e| e.to_string())?;
                    if let Ok(m) = LoadLibraryA(PCSTR(c.as_ptr() as *const u8)) {
                        module = Some(m);
                        break;
                    }
                }
                let module = module.ok_or("nvml.dll not found")?;
                let sym = |name: &str| {
                    let c = CString::new(name).ok()?;
                    GetProcAddress(module, PCSTR(c.as_ptr() as *const u8))
                };
                let init: InitFn = std::mem::transmute(sym("nvmlInit_v2").ok_or("nvmlInit_v2 missing")?);
                let get_handle: HandleFn = std::mem::transmute(
                    sym("nvmlDeviceGetHandleByIndex_v2").ok_or("nvmlDeviceGetHandleByIndex_v2 missing")?,
                );
                let temp: TempFn =
                    std::mem::transmute(sym("nvmlDeviceGetTemperature").ok_or("nvmlDeviceGetTemperature missing")?);
                let power: PowerFn =
                    std::mem::transmute(sym("nvmlDeviceGetPowerUsage").ok_or("nvmlDeviceGetPowerUsage missing")?);
                let temp_v: Option<TempVFn> =
                    sym("nvmlDeviceGetTemperatureV").map(|f| std::mem::transmute(f));
                let clock: Option<ClockFn> = sym("nvmlDeviceGetClockInfo").map(|f| std::mem::transmute(f));
                let fields: Option<FieldsFn> = sym("nvmlDeviceGetFieldValues").map(|f| std::mem::transmute(f));
                let mem_info: Option<MemInfoFn> = sym("nvmlDeviceGetMemoryInfo").map(|f| std::mem::transmute(f));
                let num_fans: Option<NumFansFn> = sym("nvmlDeviceGetNumFans").map(|f| std::mem::transmute(f));
                let fan_pct: Option<FanPctFn> = sym("nvmlDeviceGetFanSpeed_v2").map(|f| std::mem::transmute(f));
                let fan_rpm: Option<FanRpmFn> = sym("nvmlDeviceGetFanSpeedRPM").map(|f| std::mem::transmute(f));
                let rc = init();
                if rc != 0 {
                    return Err(format!("nvmlInit error {rc}"));
                }
                let mut dev: *mut c_void = std::ptr::null_mut();
                let rc = get_handle(0, &mut dev);
                if rc != 0 || dev.is_null() {
                    return Err(format!("nvmlDeviceGetHandleByIndex error {rc}"));
                }
                let n = Nvml { clock, dev, temp, temp_v, power, fields, mem_info, num_fans, fan_pct, fan_rpm };
                // Real test: if even the first reading fails, better to fall back to nvidia-smi.
                if n.sample().0.is_none() {
                    return Err("NVML did not return a temperature".into());
                }
                Ok(n)
            }
        }

        fn sample(&self) -> Reading {
            unsafe {
                let mut t = 0u32;
                let mut p = 0u32;
                let mut temp = ((self.temp)(self.dev, 0, &mut t) == 0).then_some(t as i32);
                if temp.is_none() {
                    // RTX 50 / recent NVML: the classic function doesn't respond, the "V" version is needed.
                    if let Some(f) = self.temp_v {
                        let mut tv = TempV { version: TEMP_V1, sensor_type: 0, temperature: 0 };
                        if f(self.dev, &mut tv) == 0 {
                            temp = Some(tv.temperature);
                        }
                    }
                }
                let power = ((self.power)(self.dev, &mut p) == 0).then_some((p / 1000) as i32);
                let mut c = 0u32;
                let clock = self
                    .clock
                    .and_then(|f| (f(self.dev, 0, &mut c) == 0).then_some(c as i32));
                (temp, power, clock, self.mem_temp(), self.vram(), self.fan())
            }
        }

        /// Fastest fan of the card as (RPM, %). With zero-RPM mode both read 0 until the fans start.
        /// RPM needs a recent driver (`nvmlDeviceGetFanSpeedRPM`); the percentage works on older ones.
        fn fan(&self) -> (Option<i32>, Option<i32>) {
            let n = self
                .num_fans
                .and_then(|f| {
                    let mut c = 0u32;
                    unsafe { (f(self.dev, &mut c) == 0).then_some(c) }
                })
                .unwrap_or(1)
                .clamp(1, 8);
            let (mut rpm, mut pct): (Option<i32>, Option<i32>) = (None, None);
            for i in 0..n {
                if let Some(f) = self.fan_rpm {
                    let mut info = FanSpeedInfo { version: FAN_SPEED_INFO_V1, fan: i, speed: 0 };
                    if unsafe { f(self.dev, &mut info) } == 0 && info.speed < 30_000 {
                        rpm = rpm.max(Some(info.speed as i32));
                    }
                }
                if let Some(f) = self.fan_pct {
                    let mut p = 0u32;
                    if unsafe { f(self.dev, i, &mut p) } == 0 && p <= 200 {
                        pct = pct.max(Some(p as i32));
                    }
                }
            }
            (rpm, pct)
        }

        /// Video memory (used MB, total MB) through `nvmlDeviceGetMemoryInfo`.
        fn vram(&self) -> Option<(i32, i32)> {
            let f = self.mem_info?;
            let mut m = NvmlMemory { total: 0, free: 0, used: 0 };
            unsafe {
                if f(self.dev, &mut m) != 0 || m.total == 0 {
                    return None;
                }
            }
            Some(((m.used / 1_048_576) as i32, (m.total / 1_048_576) as i32))
        }

        /// Memory temperature through `nvmlDeviceGetFieldValues(NVML_FI_DEV_MEMORY_TEMP)`.
        /// `None` if the driver/GPU doesn't report it (or returns an implausible value).
        fn mem_temp(&self) -> Option<i32> {
            let f = self.fields?;
            let mut fv = FieldValue {
                field_id: NVML_FI_DEV_MEMORY_TEMP,
                scope_id: 0,
                timestamp: 0,
                latency_usec: 0,
                value_type: 0,
                nvml_return: 0,
                value: [0; 8],
            };
            unsafe {
                if f(self.dev, 1, &mut fv) != 0 || fv.nvml_return != 0 {
                    return None;
                }
            }
            // nvmlValueType_t: 0 double, 1 uint, 2 ulong (4 bytes on Windows), 3 ulonglong, 4 slonglong, 5 sint
            let v = match fv.value_type {
                0 => f64::from_le_bytes(fv.value).round() as i64,
                1 | 2 => u32::from_le_bytes([fv.value[0], fv.value[1], fv.value[2], fv.value[3]]) as i64,
                3 => u64::from_le_bytes(fv.value) as i64,
                4 => i64::from_le_bytes(fv.value),
                5 => i32::from_le_bytes([fv.value[0], fv.value[1], fv.value[2], fv.value[3]]) as i64,
                _ => return None,
            };
            plausible(v as i32)
        }
    }

    /// Sensors report 0 / 255 / garbage when a reading isn't real.
    fn plausible(t: i32) -> Option<i32> {
        (1..=150).contains(&t).then_some(t)
    }

    type Shared = Arc<Mutex<Reading>>;

    fn smi_path() -> PathBuf {
        for p in [
            "C:\\Windows\\System32\\nvidia-smi.exe",
            "C:\\Program Files\\NVIDIA Corporation\\NVSMI\\nvidia-smi.exe",
        ] {
            if std::path::Path::new(p).is_file() {
                return PathBuf::from(p);
            }
        }
        PathBuf::from("nvidia-smi")
    }

    fn smi_query(fields: &str) -> Option<String> {
        let out = Command::new(smi_path())
            .args([&format!("--query-gpu={fields}"), "--format=csv,noheader,nounits", "-i", "0"])
            .stdin(Stdio::null())
            .stderr(Stdio::null())
            .creation_flags(0x0800_0000) // CREATE_NO_WINDOW
            .output()
            .ok()?;
        out.status.success().then(|| String::from_utf8_lossy(&out.stdout).into_owned())
    }

    fn run_smi() -> Option<Reading> {
        // Fields missing in old nvidia-smi builds make the whole query fail, so try the richest
        // query first and fall back to shorter ones. Positions: 0 temp, 1 power, 2 clock,
        // 3 memory temp, 4 VRAM used, 5 VRAM total, 6 fan %.
        const TIERS: [&str; 4] = [
            "temperature.gpu,power.draw,clocks.gr,temperature.memory,memory.used,memory.total,fan.speed",
            "temperature.gpu,power.draw,clocks.gr,temperature.memory,memory.used,memory.total",
            "temperature.gpu,power.draw,clocks.gr,temperature.memory",
            "temperature.gpu,power.draw,clocks.gr",
        ];
        let text = TIERS.iter().find_map(|f| smi_query(f))?;
        let vals: Vec<Option<i32>> = text
            .lines()
            .next()?
            .split(',')
            .map(|v| v.trim().parse::<f32>().ok().map(|v| v.round() as i32))
            .collect();
        let at = |i: usize| vals.get(i).copied().flatten();
        let temp = at(0)?;
        let vram = match (at(4), at(5)) {
            (Some(u), Some(t)) if t > 0 => Some((u, t)),
            _ => None,
        };
        Some((Some(temp), at(1), at(2), at(3).and_then(plausible), vram, (None, at(6))))
    }

    /// Text report for `--diag`: what NVML sees and what nvidia-smi returns.
    pub fn diag() -> String {
        let mut out = String::new();
        match Nvml::new() {
            Ok(n) => {
                let (t, w, c, m, v, f) = n.sample();
                out.push_str(&format!("NVML: OK  temperature={t:?} power={w:?} clock={c:?} mem_temp={m:?} vram(used,total MB)={v:?} gpu_fan(rpm,%)={f:?}\n"));
                out.push_str("Hotspot: not available through NVML; read natively via PawnIO (see \"Native hotspot\" below), HWiNFO shared memory as fallback\n");
            }
            Err(e) => out.push_str(&format!("NVML: FAILED ({e})\n")),
        }
        let o = Command::new(smi_path())
            .args(["--query-gpu=name,temperature.gpu,power.draw", "--format=csv,noheader", "-i", "0"])
            .stdin(Stdio::null())
            .creation_flags(0x0800_0000)
            .output();
        match o {
            Ok(o) => out.push_str(&format!(
                "nvidia-smi: code={:?} out='{}' err='{}'\n",
                o.status.code(),
                String::from_utf8_lossy(&o.stdout).trim(),
                String::from_utf8_lossy(&o.stderr).trim()
            )),
            Err(e) => out.push_str(&format!("nvidia-smi: could not launch ({e})\n")),
        }
        out
    }

    enum Source {
        Nvml(Nvml),
        Smi(Shared),
    }

    pub struct NvSensor {
        src: Source,
        info: String,
    }

    impl NvSensor {
        pub fn new() -> Option<Self> {
            match Nvml::new() {
                Ok(n) => Some(NvSensor { src: Source::Nvml(n), info: "NVML".into() }),
                Err(why) => {
                    // Fallback: nvidia-smi. If it doesn't work even once, no sensor at all.
                    let first = run_smi()?;
                    let shared: Shared = Arc::new(Mutex::new(first));
                    let s2 = shared.clone();
                    std::thread::spawn(move || loop {
                        std::thread::sleep(std::time::Duration::from_millis(1500));
                        if let Some(v) = run_smi() {
                            if let Ok(mut g) = s2.lock() {
                                *g = v;
                            }
                        }
                    });
                    Some(NvSensor { src: Source::Smi(shared), info: format!("nvidia-smi (NVML: {why})") })
                }
            }
        }

        pub fn describe(&self) -> &str {
            &self.info
        }

        /// (temperature °C, power W, clock MHz, memory temperature °C) of the first NVIDIA GPU.
        pub fn sample(&self) -> Reading {
            match &self.src {
                Source::Nvml(n) => n.sample(),
                Source::Smi(s) => s.lock().map(|g| *g).unwrap_or((None, None, None, None, None, (None, None))),
            }
        }
    }
}

#[cfg(not(windows))]
mod imp {
    pub fn diag() -> String {
        "Windows only\n".into()
    }
    pub struct NvSensor;
    impl NvSensor {
        pub fn new() -> Option<Self> {
            None
        }
        pub fn describe(&self) -> &str {
            ""
        }
        pub fn sample(&self) -> (Option<i32>, Option<i32>, Option<i32>, Option<i32>, Option<(i32, i32)>, (Option<i32>, Option<i32>)) {
            (None, None, None, None, None, (None, None))
        }
    }
}

pub use imp::{diag, NvSensor};
