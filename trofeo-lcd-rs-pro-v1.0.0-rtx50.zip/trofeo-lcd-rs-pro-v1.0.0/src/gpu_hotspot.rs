//! **Native hotspot (junction) temperature for NVIDIA GeForce RTX 50 (Blackwell)**,
//! with no third-party monitoring program running.
//!
//! NVIDIA doesn't expose the RTX 50 hotspot through NVML/NvAPI, so it has to be read
//! straight from the GPU's registers. That is done with the official, signed
//! **`Nvidia` module of PawnIO** (<https://github.com/namazso/PawnIO.Modules>, file
//! `Nvidia.p`, the same path HWMonitor 1.65.1 uses). The module supports GB202 / GB203 /
//! GB205 / GB206 / GB207 (RTX 5090 ... 5050; the 5070 Ti is a GB203). It only does
//! read-only MMIO of a few thermal registers.
//!
//! What the module returns (`ioctl_read_thermal_registers`, input = PCI bus/device/function):
//! six raw DWORDs from `BAR0 + 0xAD0A90`. The module source says channel 0 is the Hot Spot,
//! but measured on an RTX 5070 Ti (GB203) against AIDA64 the hotspot follows the **hottest
//! of the six channels** (channel 0 read 2-3 °C lower), so that is what is reported. A
//! sample is valid only when **bit 30** is set, and its value is `(raw & 0xFFFF) / 256.0` °C.
//!
//! Requirements (all one-time):
//! 1. The PawnIO driver installed (`winget install namazso.PawnIO`) — the same one the
//!    AMD CPU temperature already uses.
//! 2. `Nvidia.bin` (the signed module, from the *Releases* of PawnIO.Modules) placed next
//!    to the program (or in `resources\`), or its path in `TROFEO_NVIDIA_MODULE`.
//!
//! If anything is missing, `NvHotspot::new()` returns `Err(reason)` and the caller falls back to
//! HWiNFO's shared memory (see `sysextra.rs`).
//!
//! NOTE: written against the module source, **not yet validated on real hardware**. Run
//! `--diag` and compare "Hot Spot" with HWMonitor/HWiNFO before trusting it.

#[cfg(windows)]
mod imp {
    use crate::pawnio::PawnIo;
    use std::path::PathBuf;

    const MODULE_FILE: &str = "Nvidia.bin";
    const THERMAL_IOCTL: &str = "ioctl_read_thermal_registers";
    const MEMORY_IOCTL: &str = "ioctl_read_memory_temperatures";
    const CHANNELS: usize = 6;
    /// `MEMORY_TEMPERATURE_UNAVAILABLE` in the module (INT32_MIN).
    const MEM_UNAVAILABLE: i64 = i32::MIN as i64;

    pub struct NvHotspot {
        pawnio: PawnIo,
        /// PCI location (bus, device, function) of the GPU the module accepted.
        bdf: (u64, u64, u64),
    }

    /// Where to look for the module blob, in order.
    fn candidates() -> Vec<PathBuf> {
        let mut v = Vec::new();
        if let Ok(p) = std::env::var("TROFEO_NVIDIA_MODULE") {
            v.push(PathBuf::from(p));
        }
        if let Ok(exe) = std::env::current_exe() {
            if let Some(dir) = exe.parent() {
                v.push(dir.join(MODULE_FILE));
                v.push(dir.join("resources").join(MODULE_FILE));
            }
        }
        v.push(PathBuf::from(MODULE_FILE));
        v.push(PathBuf::from("resources").join(MODULE_FILE));
        v
    }

    fn load_blob() -> Option<Vec<u8>> {
        candidates().into_iter().find_map(|p| std::fs::read(p).ok()).filter(|b| !b.is_empty())
    }

    /// `(raw & 0xFFFF) / 256` °C when bit 30 is set; `None` for invalid / bus-error values.
    pub fn decode(raw: u64) -> Option<f32> {
        let raw = raw as u32;
        if raw & (1 << 30) == 0 {
            return None; // not valid (also rejects 0xBADFxxxx pattern: bit 30 clear)
        }
        let t = (raw & 0xFFFF) as f32 / 256.0;
        // 0xFFFFFFFF decodes to ~256 °C: reject anything that can't be a die temperature.
        (1.0..=150.0).contains(&t).then_some(t)
    }

    /// Hottest valid channel among the six raw DWORDs.
    pub fn hottest(raw: &[u64]) -> Option<f32> {
        raw.iter().filter_map(|r| decode(*r)).fold(None, |a: Option<f32>, t| Some(a.map_or(t, |x| x.max(t))))
    }

    impl NvHotspot {
        /// Opens PawnIO with the Nvidia module and finds the GPU it accepts. Scans PCI
        /// bus 0..=255 / device 0..=31 / function 0 once (the module itself rejects
        /// everything that isn't an NVIDIA display device of a supported chip), so call
        /// this from a background thread, never from the render loop.
        pub fn new() -> Result<Self, String> {
            let blob = load_blob().ok_or_else(|| {
                format!(
                    "{MODULE_FILE} not found (looked next to the program, in resources\\, in the current folder and in TROFEO_NVIDIA_MODULE)"
                )
            })?;
            let pawnio = PawnIo::open_with_module(&blob).ok_or(
                "PawnIO refused the module: the PawnIO driver is not installed/running (winget install namazso.PawnIO), \
                 or Nvidia.bin is not a signed build / is from a PawnIO.Modules release older than the driver",
            )?;
            for bus in 0..=255u64 {
                for dev in 0..=31u64 {
                    let bdf = (bus, dev, 0u64);
                    if let Some(out) = pawnio.execute(THERMAL_IOCTL, &[bdf.0, bdf.1, bdf.2], CHANNELS) {
                        if out.len() == CHANNELS {
                            return Ok(NvHotspot { pawnio, bdf });
                        }
                    }
                }
            }
            Err("module loaded, but no supported GPU answered on the PCI bus (only RTX 50 / GB202-GB207 is supported, and the GPU must be awake)".into())
        }

        fn raw(&self) -> Option<Vec<u64>> {
            let (b, d, f) = self.bdf;
            self.pawnio.execute(THERMAL_IOCTL, &[b, d, f], CHANNELS).filter(|o| o.len() == CHANNELS)
        }

        /// Hotspot in °C: the hottest valid channel (matches AIDA64 within ~1 °C on a 5070 Ti,
        /// while channel 0 alone read 2-3 °C low). `None` if no channel has a valid sample.
        pub fn hotspot_c(&self) -> Option<i32> {
            let raw = self.raw()?;
            hottest(&raw).map(|t| t.round() as i32)
        }

        /// Hottest memory chip in °C (8 sensors on a 5070 Ti; matched AIDA64's "GPU memory"
        /// exactly). Useful when NVML doesn't report the memory temperature.
        pub fn mem_temp_c(&self) -> Option<i32> {
            let (b, d, f) = self.bdf;
            let m = self.pawnio.execute(MEMORY_IOCTL, &[b, d, f], 50)?;
            if m.len() != 50 {
                return None;
            }
            m[2..].iter().map(|v| *v as i64).filter(|t| *t != MEM_UNAVAILABLE && (1..=150).contains(t)).max().map(|t| t as i32)
        }

        /// Text report for `--diag`: every raw channel and its decoded value, plus the
        /// hottest memory chip, so the numbers can be compared with HWMonitor/HWiNFO.
        pub fn diag(&self) -> String {
            let (b, d, f) = self.bdf;
            let mut s = format!("Native hotspot (PawnIO Nvidia module): GPU at PCI {b:02x}:{d:02x}.{f}\n");
            match self.raw() {
                Some(raw) => {
                    s.push_str(&format!("  hotspot reported (hottest valid channel): {:?} C\n", hottest(&raw)));
                    for (i, r) in raw.iter().enumerate() {
                        let name = if i == 0 { "module: Hot Spot" } else { "extra" };
                        s.push_str(&format!(
                            "  channel {i} ({name}): raw=0x{:08X} -> {:?} C\n",
                            *r as u32,
                            decode(*r)
                        ));
                    }
                }
                None => s.push_str("  thermal read failed\n"),
            }
            let (b, d, f) = self.bdf;
            if let Some(m) = self.pawnio.execute(MEMORY_IOCTL, &[b, d, f], 50) {
                if m.len() == 50 {
                    let temps: Vec<i64> =
                        m[2..].iter().map(|v| *v as i64).filter(|t| *t != MEM_UNAVAILABLE && (1..=150).contains(t)).collect();
                    s.push_str(&format!(
                        "  memory chips: {} sensors, max {:?} C\n",
                        temps.len(),
                        temps.iter().max()
                    ));
                }
            }
            s
        }
    }

    #[cfg(test)]
    mod tests {
        use super::{decode, hottest};

        #[test]
        fn decodes_valid_and_rejects_garbage() {
            // 55.59 C idle on a GB203: 55.59 * 256 = 14231 = 0x3797, bit 30 set
            assert_eq!(decode(0x4000_3797).map(|t| (t * 100.0).round() as i32), Some(5559));
            // bit 30 not set -> invalid sample
            assert_eq!(decode(0x0000_3797), None);
            // bus error markers and all-ones
            assert_eq!(decode(0xBADF_5040), None);
            assert_eq!(decode(0xFFFF_FFFF), None);
        }

        #[test]
        fn hotspot_is_hottest_valid_channel() {
            // Real sample from a 5070 Ti: channels 3 and 4 are the hottest (51.3125 C)
            let raw = [0x4000_31B0, 0x4000_3038, 0x4000_3028, 0x4000_3350, 0x4000_3350, 0x4000_30A0];
            assert_eq!(hottest(&raw), Some(51.3125));
            // invalid channels are ignored, none valid -> None
            assert_eq!(hottest(&[0xBADF_5040, 0x4000_3350, 0xFFFF_FFFF]), Some(51.3125));
            assert_eq!(hottest(&[0xBADF_5040, 0]), None);
        }
    }
}

#[cfg(not(windows))]
mod imp {
    pub struct NvHotspot;
    impl NvHotspot {
        pub fn new() -> Result<Self, String> {
            Err("Windows only".into())
        }
        pub fn hotspot_c(&self) -> Option<i32> {
            None
        }
        pub fn diag(&self) -> String {
            String::new()
        }
    }
}

pub use imp::NvHotspot;
