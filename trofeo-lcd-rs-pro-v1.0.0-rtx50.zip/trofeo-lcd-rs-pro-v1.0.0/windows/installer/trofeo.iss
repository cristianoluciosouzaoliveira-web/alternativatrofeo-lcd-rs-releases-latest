﻿; Trofeo Pro Dashboard - Windows installer (Inno Setup 6).
; Build:  windows\installer\build-installer.ps1   (compiles the exe, then this script)
; Output: windows\installer\Output\TrofeoDashboard-Setup-<version>.exe

#ifndef AppVersion
  #define AppVersion "1.1.1"
#endif
#define AppName "Trofeo Pro Dashboard"

[Setup]
; Fixed id so a new installer upgrades the previous install instead of installing next to it.
AppId={{8B2F4C1A-6D3E-4E5B-9A7C-1F0D2E3B4C5A}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher=Trofeo LCD community
DefaultDirName={autopf}\TrofeoDashboard
DefaultGroupName={#AppName}
DisableProgramGroupPage=yes
; Admin: it registers an elevated scheduled task (autostart without UAC prompts) and talks to the USB panel.
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
LicenseFile=..\..\LICENSE
OutputDir=Output
OutputBaseFilename=TrofeoDashboard-Setup-{#AppVersion}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayName={#AppName}
UninstallDisplayIcon={app}\trofeo_lcd.exe

[Languages]
Name: "ptbr"; MessagesFile: "compiler:Languages\BrazilianPortuguese.isl"
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Criar atalho na Área de Trabalho"
Name: "rtx50"; Description: "Sensores nativos: hotspot da RTX 50 e RPM do cooler, sem HWiNFO (driver PawnIO + módulos Nvidia.bin e LpcIO.bin, precisa de internet)"; Flags: unchecked

[Dirs]
; The config editor and the logs write next to the exe, so normal users need write access to the folder.
Name: "{app}"; Permissions: users-modify

[Files]
Source: "..\..\target\release\trofeo_lcd.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\..\target\release\trofeo_screen.exe"; DestDir: "{app}"; Flags: ignoreversion skipifsourcedoesntexist
Source: "..\..\target\release\trofeo_config.exe"; DestDir: "{app}"; Flags: ignoreversion skipifsourcedoesntexist
Source: "..\scripts\*"; DestDir: "{app}\scripts"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\restart.bat"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\choose-layout.bat"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\preview.bat"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\diag.bat"; DestDir: "{app}"; Flags: ignoreversion
; Never overwrite the user's settings on upgrade.
Source: "..\trofeo.conf"; DestDir: "{app}"; Flags: onlyifdoesntexist uninsneveruninstall
Source: "..\..\trofeo.conf.example"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\..\README.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\..\NOTICE.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\..\LICENSE"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
; Starting through the scheduled task keeps it elevated WITHOUT a UAC prompt.
Name: "{group}\Trofeo Dashboard"; Filename: "{sys}\schtasks.exe"; Parameters: "/run /tn TrofeoLCD"; IconFilename: "{app}\trofeo_lcd.exe"; Flags: runminimized
Name: "{group}\Reiniciar"; Filename: "{app}\restart.bat"; WorkingDir: "{app}"
Name: "{group}\Escolher layout"; Filename: "{app}\choose-layout.bat"; WorkingDir: "{app}"
Name: "{group}\Configurações"; Filename: "{app}\trofeo_config.exe"; WorkingDir: "{app}"
Name: "{group}\Diagnóstico"; Filename: "{app}\diag.bat"; WorkingDir: "{app}"
Name: "{group}\Desinstalar"; Filename: "{uninstallexe}"
Name: "{autodesktop}\Trofeo Dashboard"; Filename: "{sys}\schtasks.exe"; Parameters: "/run /tn TrofeoLCD"; IconFilename: "{app}\trofeo_lcd.exe"; Flags: runminimized; Tasks: desktopicon

[Run]
; Stops old instances, registers the elevated autostart task (TrofeoLCD) and starts the dashboard.
Filename: "powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\scripts\setup.ps1"""; Flags: runhidden waituntilterminated; StatusMsg: "Registrando a inicialização automática e iniciando o painel..."
; Optional: PawnIO driver + signed Nvidia.bin (needs internet). The checkbox is the consent, hence -Yes.
Filename: "powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\scripts\rtx50-hotspot.ps1"" -Yes"; Flags: runhidden waituntilterminated; Tasks: rtx50; StatusMsg: "Instalando a leitura nativa do hotspot da RTX 50..."

[UninstallRun]
Filename: "{sys}\taskkill.exe"; Parameters: "/im trofeo_lcd.exe /f"; Flags: runhidden; RunOnceId: "KillLcd"
Filename: "{sys}\taskkill.exe"; Parameters: "/im trofeo_screen.exe /f"; Flags: runhidden; RunOnceId: "KillScreen"
Filename: "powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\scripts\uninstall-autostart.ps1"""; Flags: runhidden waituntilterminated; RunOnceId: "RemoveTask"

[UninstallDelete]
Type: files; Name: "{app}\trofeo-errors.txt"
Type: files; Name: "{app}\install_log.txt"
Type: files; Name: "{app}\diag.txt"
Type: files; Name: "{app}\Nvidia.bin"
Type: files; Name: "{app}\LpcIO.bin"

[Code]
// Upgrade: the running (elevated) dashboard locks the exe, so stop it before copying files.
function PrepareToInstall(var NeedsRestart: Boolean): String;
var
  rc: Integer;
begin
  Exec(ExpandConstant('{sys}\schtasks.exe'), '/end /tn TrofeoLCD', '', SW_HIDE, ewWaitUntilTerminated, rc);
  Exec(ExpandConstant('{sys}\taskkill.exe'), '/im trofeo_lcd.exe /f', '', SW_HIDE, ewWaitUntilTerminated, rc);
  Exec(ExpandConstant('{sys}\taskkill.exe'), '/im trofeo_screen.exe /f', '', SW_HIDE, ewWaitUntilTerminated, rc);
  Sleep(1000);
  Result := '';
end;
