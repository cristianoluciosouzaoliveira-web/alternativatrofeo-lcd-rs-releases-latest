# Builds the Windows installer:  cargo build --release  ->  Inno Setup  ->  TrofeoDashboard-Setup-<version>.exe
# Run from anywhere:  powershell -ExecutionPolicy Bypass -File windows\installer\build-installer.ps1
$ErrorActionPreference = 'Stop'
$root = Resolve-Path (Join-Path $PSScriptRoot '..\..')
Set-Location $root

$ver = (Select-String -Path 'Cargo.toml' -Pattern '^version\s*=\s*"([^"]+)"' | Select-Object -First 1).Matches[0].Groups[1].Value
Write-Host "Version: $ver"

cargo build --release --bins
if ($LASTEXITCODE -ne 0) { throw 'cargo build failed' }

$iscc = @(
    "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe",
    "$env:ProgramFiles\Inno Setup 6\ISCC.exe",
    "$env:LOCALAPPDATA\Programs\Inno Setup 6\ISCC.exe"
) | Where-Object { Test-Path $_ } | Select-Object -First 1

if (-not $iscc) {
    Write-Host 'Inno Setup 6 not found. Installing it with winget (JRSoftware.InnoSetup)...'
    winget install --id JRSoftware.InnoSetup -e --accept-package-agreements --accept-source-agreements
    $iscc = @(
        "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe",
        "$env:ProgramFiles\Inno Setup 6\ISCC.exe",
        "$env:LOCALAPPDATA\Programs\Inno Setup 6\ISCC.exe"
    ) | Where-Object { Test-Path $_ } | Select-Object -First 1
    if (-not $iscc) { throw 'Inno Setup was installed but ISCC.exe was not found; open a new PowerShell and run this again.' }
}

& $iscc "/DAppVersion=$ver" (Join-Path $PSScriptRoot 'trofeo.iss')
if ($LASTEXITCODE -ne 0) { throw 'Inno Setup failed' }

$out = Join-Path $PSScriptRoot "Output\TrofeoDashboard-Setup-$ver.exe"
Write-Host "`nInstaller ready: $out" -ForegroundColor Green
