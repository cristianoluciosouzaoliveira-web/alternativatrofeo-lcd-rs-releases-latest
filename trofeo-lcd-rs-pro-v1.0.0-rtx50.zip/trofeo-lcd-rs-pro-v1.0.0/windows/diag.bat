@echo off
cd /d "%~dp0"
echo Collecting sensor diagnostics (takes a few seconds)...
trofeo_lcd.exe --diag > diag.txt 2>&1
type diag.txt | findstr /i "NVML nvidia-smi hotspot Hot channel memory Sensor"
echo.
echo Full report saved to diag.txt
pause
