# Trofeo Pro Dashboard - native sensors setup (RTX 50 hotspot + fan RPM), opt-in, run elevated.
#  1. checks that trofeo_lcd.exe is a build that has the native reader
#  2. makes sure the PawnIO driver is installed (asks first: it is a kernel driver)
#  3. downloads the signed Nvidia.bin (RTX 50 hotspot) and LpcIO.bin (fan RPM) modules from the official PawnIO.Modules releases
#  4. restarts the dashboard
param([switch]$Yes)   # -Yes: do not ask (the installer checkbox already is the consent)
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$dir  = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$exe  = Join-Path $dir 'trofeo_lcd.exe'
$dest = Join-Path $dir 'Nvidia.bin'
$hdr  = @{ 'User-Agent' = 'trofeo-setup' }

Write-Host "=== RTX 50 native hotspot setup ==="

# 1. Is this exe a build that contains the native reader?
$bytes = [IO.File]::ReadAllBytes($exe)
$text  = [Text.Encoding]::ASCII.GetString($bytes)
if ($text -notmatch 'ioctl_read_thermal_registers') {
    Write-Host "`nWARNING: this trofeo_lcd.exe is the OLD build (no native RTX 50 hotspot reader)." -ForegroundColor Yellow
    Write-Host "Build the new one from the source zip (cargo build --release) and replace trofeo_lcd.exe here,"
    Write-Host "then run this script again. Continuing anyway: the module download is harmless."
}

# 2. PawnIO driver
$pawn = Join-Path $env:ProgramFiles 'PawnIO\PawnIOLib.dll'
if (-not (Test-Path $pawn)) {
    Write-Host "`nPawnIO driver not found. It is a signed kernel driver that lets the program read hardware registers"
    Write-Host "(same one used for AMD CPU temperature). https://pawnio.eu"
    $a = if ($Yes) { 'y' } else { Read-Host "Install it now with winget? (y/N)" }
    if ($a -match '^[yYsS]') {
        winget install --id namazso.PawnIO -e --accept-package-agreements --accept-source-agreements
    } else {
        Write-Host "Skipped. Install PawnIO yourself and run this script again."
    }
} else { Write-Host "PawnIO: found." }

# 3. Signed PawnIO modules from the official releases:
#    Nvidia.bin = RTX 50 hotspot, LpcIO.bin = fan RPM (ITE Super I/O). Each one is optional and independent.
$modules = @('Nvidia.bin', 'LpcIO.bin')
try {
    $rel = Invoke-RestMethod 'https://api.github.com/repos/namazso/PawnIO.Modules/releases/latest' -Headers $hdr
    Write-Host "PawnIO.Modules release: $($rel.tag_name)"
    $zipAsset = $rel.assets | Where-Object { $_.name -like '*.zip' } | Select-Object -First 1
    $zipPath = $null
    foreach ($name in $modules) {
        $dest = Join-Path $dir $name
        try {
            $asset = $rel.assets | Where-Object { $_.name -eq $name } | Select-Object -First 1
            if ($asset) {
                Invoke-WebRequest $asset.browser_download_url -OutFile $dest -Headers $hdr
            } else {
                if (-not $zipAsset) { throw "no $name or .zip asset in release $($rel.tag_name)" }
                if (-not $zipPath) {
                    $zipPath = Join-Path $env:TEMP 'pawnio-modules.zip'
                    Invoke-WebRequest $zipAsset.browser_download_url -OutFile $zipPath -Headers $hdr
                }
                Add-Type -AssemblyName System.IO.Compression.FileSystem
                $z = [IO.Compression.ZipFile]::OpenRead($zipPath)
                try {
                    $e = $z.Entries | Where-Object { $_.Name -eq $name } | Select-Object -First 1
                    if (-not $e) { throw "$name is not inside $($zipAsset.name) (release $($rel.tag_name) may predate the module)" }
                    [IO.Compression.ZipFileExtensions]::ExtractToFile($e, $dest, $true)
                } finally { $z.Dispose() }
            }
            if ((Get-Item $dest).Length -le 0) { throw "downloaded file is empty" }
            Write-Host "$name saved: $dest ($((Get-Item $dest).Length) bytes)" -ForegroundColor Green
        } catch {
            Write-Host "`nCould not get ${name}: $($_.Exception.Message)" -ForegroundColor Yellow
            Write-Host "Download it by hand from https://github.com/namazso/PawnIO.Modules/releases and put it next to trofeo_lcd.exe."
        }
    }
    if ($zipPath) { Remove-Item $zipPath -ErrorAction SilentlyContinue }
} catch {
    Write-Host "`nCould not read the PawnIO.Modules releases: $($_.Exception.Message)" -ForegroundColor Yellow
    Write-Host "Download Nvidia.bin / LpcIO.bin by hand from https://github.com/namazso/PawnIO.Modules/releases and put them next to trofeo_lcd.exe."
}

# 4. Restart the dashboard
Get-Process trofeo_lcd -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Seconds 1
if (Get-ScheduledTask -TaskName 'TrofeoLCD' -ErrorAction SilentlyContinue) { Start-ScheduledTask -TaskName 'TrofeoLCD' }
Write-Host "`nNow run diag.bat and compare the hotspot, fan and drive lines with AIDA64/HWMonitor."
