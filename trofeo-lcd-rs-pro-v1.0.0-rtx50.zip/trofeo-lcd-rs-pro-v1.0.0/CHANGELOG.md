# Changelog

## Unreleased

### New layouts
- Three new landscape designs for the Pro dashboards (`pro_layout = levels | versus | aurora`; `all` rotates through them too): **levels** (a mixing desk: five long LED level meters for CPU, GPU, memory, disk and network), **versus** (CPU against GPU with temperature, load, history graph and readings; the clock and the track in the middle) and **aurora** (frosted-glass cards over soft glowing colors). A test checks that every layout name is unique and finds its layout. Not yet seen on screen.

### New themes
- Eight new color themes for the Pro dashboards (`pro_theme = ...`, and `all` cycles through them): `forest`, `ocean`, `sunset`, `matrix`, `rose`, `brasil`, `dracula`, `nord`. Added to the list in `choose-layout.ps1`. A test checks that every theme is dark, has readable text colors and a unique name. Not yet seen on screen.

### Brazilian Portuguese
- `language = pt` (the existing Portuguese) is now Brazilian: the Pro dashboards' labels, written in English in the layouts, are translated through `i18n::pro_label` (`PROCESSADOR`, `PLACA DE VÍDEO`, `MEMÓRIA`, `DISCOS`, `REDE`, `TOCANDO AGORA`, `CLIMA`, `POTÊNCIA`, `USO`, `TEMPO DE QUADRO`, `FAN/BOMBA`...) with accents, since those layouts use a Unicode font; weekday and forecast names get their accents (`TERÇA-FEIRA`, `SÁB`). Weather widget: `CLIMA` and `NEBLINA`. The other languages keep the English labels there. Bitmap-font layouts still write Portuguese without accents. The settings editor (`trofeo_config.exe`) now speaks Brazilian Portuguese too (button `PT`, `--lang pt`, **the default**): all 242 labels, hints, section and screen names and buttons are translated through one English-to-Portuguese table (`src/schema_pt.rs`), and a test checks that no setting is left untranslated. Not yet checked on screen.

### NVIDIA GPU fans
- The GPU fan stat now works on NVIDIA through NVML: RPM (`nvmlDeviceGetFanSpeedRPM`, recent drivers) or, if the driver can't report it, the fan percentage (`nvmlDeviceGetFanSpeed_v2`, `fan.speed` in the nvidia-smi fallback). With zero-RPM mode it shows `0` until the fans start, then the real value (the fastest fan of the card). `--diag` prints `gpu_fan(rpm,%)`. Not yet validated on hardware.

### NVIDIA video memory
- The graphics tile now shows NVIDIA VRAM used / **total** (e.g. `4.3 /16 GB`; designs that print one value followed by GB show `used/total`, e.g. `2.3/16`), read through NVML (`nvmlDeviceGetMemoryInfo`) with a `memory.used,memory.total` fallback in nvidia-smi. Before, only AMD cards filled it.

### Fan RPM (water cooler) without HWiNFO
- New native reader for the motherboard's **ITE IT8689E** Super I/O through PawnIO's official `LpcIO` module (`src/superio_fan.rs`): the CPU_FAN RPM (radiator fans) shows in the Processor tile with no monitoring program running; HWiNFO stays as fallback. All six tachometers are listed by `--diag`; `TROFEO_CPU_FAN_TACH=<1-6>` picks the one shown (default 1). Only the IT8689E is supported for now. Measured on an IT8689E: the tachometers are always 16-bit (the 8-bit interpretation gave absurd 10000+ RPM). 
- The CPU fan stat also shows the **water cooler pump** (CPU_OPT, tach 5) as `FAN/PUMP`, e.g. `1618/3325 RPM`; `TROFEO_PUMP_TACH=<1-6|off>` changes or hides it. Tachs 1 (radiator), 2, 3, 4 and 5 (pump) matched AIDA64 within 1 % on a Gigabyte A620/B650 board with an ITE IT8689E.
- `windows/scripts/rtx50-hotspot.ps1` (installer checkbox) now also downloads `LpcIO.bin`.

### Installer
- New Inno Setup installer (`windows/installer`): installs to Program Files, registers the elevated autostart task, adds shortcuts and an uninstaller, keeps `trofeo.conf` on upgrade, optional RTX 50 hotspot setup. Built by `build-installer.ps1` and by the release workflow. Not yet tested on Windows.

### Drive temperatures
- The default (Pro) layout's STORAGE tile now lists every drive with its model and temperature (when there are 2 or more); the ring and the footer keep showing the system drive's usage. Other layouts still show the system drive only.
- The SSD temperature now tries three methods per drive: Windows' storage temperature property, the NVMe SMART/Health log and ATA SMART attribute 194/190 (SATA SSD/HDD, needs administrator). Before, only the first was tried, and it returned nothing on some NVMe drives.
- `--diag` lists every physical drive with its model, temperature and the method that worked. Checked against AIDA64 on one machine (NVMe Kingston 39 °C via NVMe SMART, NVMe XPG 42 °C and SATA HDD 37 °C via the storage property): all three matched.

### NVIDIA GeForce RTX 50 (Blackwell)
- **Hotspot, native:** read directly from the GPU registers through the official signed `Nvidia` module of PawnIO (the same path HWMonitor 1.65.1 uses; GB202/203/205/206/207 = RTX 5090 ... 5050). No monitoring program needed. Requires the PawnIO driver (already used for the AMD CPU) and `Nvidia.bin` from the PawnIO.Modules releases next to the program. **Validated on an RTX 5070 Ti against AIDA64: the hotspot is the hottest of the module's six thermal channels (channel 0 alone read 2-3 °C low), and its memory chips' maximum matched AIDA64 exactly.**
- **Hotspot, fallback:** HWiNFO's shared memory (RTX 50 needs HWiNFO 8.51+; also RTX 20/30/40 and AMD). Ignores the invalid 255 °C marker and the GDDR6X "memory junction".
- New: **memory temperature** from NVML (`NVML_FI_DEV_MEMORY_TEMP`), or the hottest chip read by the native module when NVML doesn't report it (the case on the 5070 Ti) with a `temperature.memory` fallback in nvidia-smi. Layouts show it as `MEM TEMP` when there is no hotspot.
- `--diag` prints every raw thermal channel of the native reader, the memory chips' temperature and the HWiNFO hotspot, to compare against HWMonitor/HWiNFO.

## Pro Dashboard 1.0 — 2026-10-20

First release of the **pro** dashboard on top of `trofeo-lcd-rs` 1.1.0.

### New layouts
- **Landscape:** `bento`, `terminal`, `chamfer`, `rings`, `dots` (join `classic`, `cockpit`, `focus`).
- **Portrait** (vertically mounted panel, `pro_rotate = cw|ccw`): `lock`, `equalizer`, `receipt`, `synthwave`, `blueprint`.
- `pro_layout = all` cycles every landscape layout; `pro_layout = portrait` cycles the portrait ones.

### Features
- Elapsed / total time next to the progress bar in the now-playing area.
- Volume / mute pop-up and "new song" pop-up (rotated correctly in portrait).
- Accent colors that follow the album art (`pro_cover_color`).
- CPU fan, GPU fan and hotspot, VRAM, FPS + frame-time, SSD temperature and read / write throughput on every layout.
- Weather with a 3-day forecast.
- Bundled **Chakra Petch** font (Light / Regular / Medium) with full Vietnamese diacritics.
- Windows helper package: `install.bat`, `choose-layout.bat`, `restart.bat`, `uninstall.bat`, `preview.bat`.

### Under the hood
- New software-rendered, anti-aliased painter (`tiles.rs`, `smooth_font.rs`); redraws only when the displayed data changes.
- `Layer::rotate_into` for portrait output; marquee disabled in portrait (ellipsis instead).
- Preview CLI: `--preview-png <file> --preview-state idle|music --config <file>`.
